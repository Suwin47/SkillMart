# Learning Management System

Demo MERN Learning Management System for the SkillMart portfolio.

Modules
- Student Dashboard
- Instructor Dashboard
- Admin Dashboard
- Course Management
- Video Lessons
- Assignments
- Quiz System
- Progress Tracking

Portfolio demonstration project.
