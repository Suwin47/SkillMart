Restaurant Website Template

Demo template created for the SkillMart portfolio.

Pages:
- Home
- About
- Menu
- Reservation
- Gallery
- Contact

License:
Portfolio / Demo use.
