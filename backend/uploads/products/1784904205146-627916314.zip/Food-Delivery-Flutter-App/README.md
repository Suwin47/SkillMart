# Food Delivery Flutter App
Demo Flutter project package for SkillMart.