# E-Commerce Database Design
Demo database package for SkillMart.