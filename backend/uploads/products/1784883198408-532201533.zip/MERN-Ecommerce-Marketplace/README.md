# MERN E-Commerce Marketplace

Demo MERN marketplace project for the SkillMart portfolio.

Features
- Authentication
- Buyer, Seller & Admin roles
- Product Management
- Shopping Cart
- Wishlist
- Razorpay Integration
- Analytics Dashboard

This is a demonstration package.
