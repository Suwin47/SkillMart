# Hospital Management System

Demo MERN Hospital Management System for the SkillMart portfolio.

Modules:
- Patient Management
- Doctor Dashboard
- Appointment Booking
- Admin Panel
- Authentication
- Reports

Demo package for educational and portfolio use.
